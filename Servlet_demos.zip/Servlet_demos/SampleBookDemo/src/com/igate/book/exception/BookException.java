package com.igate.book.exception;
/*
 * User defined exception class
 */
public class BookException extends Exception {
	public BookException(String message) {
		super(message);
	}
}
